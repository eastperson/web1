// @TODO if cypress issue is resolved, should add clipboard test case
// https://github.com/cypress-io/cypress/issues/2386

// before(() => {
//   cy.visit('/dist');
// });

// const columns = [
//   { name: 'c1', editor: { type: 'text' } },
//   { name: 'c2', editor: { type: 'text' } },
//   { name: 'c3', editor: { type: 'text' } }
// ];

// const data = [
//   { c1: 'c1', c2: 'c2', c3: 'c3' },
//   { c1: 'c1', c2: 'c2', c3: 'c3' },
//   { c1: 'c1', c2: 'c2', c3: 'c3' },
//   { c1: 'c1', c2: 'c2', c3: 'c3' }
// ];

// const defaultOptions = {
//   data,
//   columns,
//   bodyHeight: 300,
//   columnOptions: {
//     minWidth: 150
//   }
// };

// type Address = [number, number];

// describe('copy to clipboard', () => {
//   it('basic value', () => {});
//   it('formatted value', () => {});
//   it('custom value', () => {});
// });
// it('paste', () => {});

export {};

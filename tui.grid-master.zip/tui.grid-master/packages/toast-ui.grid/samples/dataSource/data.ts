export const data = [
  {
    id: 20,
    name: 'Chaos And The Calm',
    artist: 'James Bay',
  },
  {
    id: 19,
    name: 'The Magic Whip',
    artist: 'Blur',
  },
  {
    id: 18,
    name: "I'm Not The Only One",
    artist: 'Sam Smith',
  },
  {
    id: 17,
    name: 'Blurryface',
    artist: 'Twenty One Pilots',
  },
  {
    id: 16,
    name: 'This Is Acting',
    artist: 'Sia',
  },
  {
    id: 15,
    name: 'Blue Skies',
    artist: 'Lenka',
  },
  {
    id: 14,
    name: 'Following My Intuition',
    artist: 'Craig David',
  },
  {
    id: 13,
    name: "I Won't Give Up",
    artist: 'Jason Mraz',
  },
  {
    id: 12,
    name: '4',
    artist: 'Beyoncé',
  },
  {
    id: 11,
    name: 'Bush',
    artist: 'Snoop Dogg',
  },
  {
    id: 10,
    name: 'Valtari',
    artist: 'Sigur Rós',
  },
  {
    id: 9,
    name: 'Get Lucky',
    artist: 'Daft Punk',
  },
  {
    id: 8,
    name: 'Make Out',
    artist: 'LANY',
  },
  {
    id: 7,
    name: 'Take Me To The Alley',
    artist: 'Gregory Porter',
  },
  {
    id: 6,
    name: 'Warm On A Cold Night',
    artist: 'HONNE',
  },
  {
    id: 5,
    name: '21',
    artist: 'Adele',
  },
  {
    id: 4,
    name: 'A Head Full Of Dreams',
    artist: 'Coldplay',
  },
  {
    id: 3,
    name: 'Moves Like Jagger',
    artist: 'Maroon5',
  },
  {
    id: 2,
    name: 'X',
    artist: 'Ed Sheeran',
  },
  {
    id: 1,
    name: 'Beautiful Lies',
    artist: 'Birdy',
  },
];

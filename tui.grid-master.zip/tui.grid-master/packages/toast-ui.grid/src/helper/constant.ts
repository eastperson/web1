export const FILTER_DEBOUNCE_TIME = 50;
export const TREE_INDENT_WIDTH = 22;

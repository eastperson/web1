import Grid from './grid';
import './css/grid.css';

Grid.setLanguage('en');
export = Grid;
